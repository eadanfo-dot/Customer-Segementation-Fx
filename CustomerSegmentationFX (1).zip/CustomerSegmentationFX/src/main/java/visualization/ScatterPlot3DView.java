package visualization;

import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Customer;
import algorithm.ClusterResult;
import javafx.embed.swing.SwingFXUtils;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class ScatterPlot3DView {

    public static void show(List<Customer> customers, ClusterResult result, String title) {
        Stage stage = new Stage();
        stage.setTitle(title);

        Group root = new Group();
        Scene scene = new Scene(root, 800, 600, true, SceneAntialiasing.BALANCED);
        scene.setFill(Color.LIGHTGRAY);

        // Camera
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateX(0);
        camera.setTranslateY(0);
        camera.setTranslateZ(-20);
        camera.setNearClip(0.1);
        camera.setFarClip(1000);
        scene.setCamera(camera);

        // Simple orbit control (basic)
        Rotate xRotate = new Rotate(20, Rotate.X_AXIS);
        Rotate yRotate = new Rotate(-30, Rotate.Y_AXIS);
        root.getTransforms().addAll(xRotate, yRotate);

        // Color palette for clusters
        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE, Color.PURPLE, Color.CYAN, Color.MAGENTA, Color.YELLOW, Color.BROWN, Color.PINK};

        // Add spheres for each point
        List<List<Customer>> clusters = result.clusters();
        for (int i = 0; i < clusters.size(); i++) {
            Color color = colors[i % colors.length];
            PhongMaterial material = new PhongMaterial(color);
            for (Customer c : clusters.get(i)) {
                // Map spending score to x, purchase to y, age to z
                double x = c.getSpendingScore() / 100.0 * 4 - 2; // scale to [-2,2]
                double y = c.getPurchaseAmount() / 600.0 * 4 - 2;
                double z = c.getAge() / 60.0 * 4 - 2;
                Sphere sphere = new Sphere(0.1);
                sphere.setMaterial(material);
                sphere.setTranslateX(x);
                sphere.setTranslateY(y);
                sphere.setTranslateZ(z);
                root.getChildren().add(sphere);
            }
        }

        // Add centroids as larger spheres
        double[][] centroids = result.centroids();
        for (double[] cent : centroids) {
            double x = cent[1] / 100.0 * 4 - 2;
            double y = cent[2] / 600.0 * 4 - 2;
            double z = cent[0] / 60.0 * 4 - 2;
            Sphere centroidSphere = new Sphere(0.15);
            centroidSphere.setMaterial(new PhongMaterial(Color.BLACK));
            centroidSphere.setTranslateX(x);
            centroidSphere.setTranslateY(y);
            centroidSphere.setTranslateZ(z);
            root.getChildren().add(centroidSphere);
        }

        // Buttons: Save as image
        Button saveBtn = new Button("Save as Image");
        saveBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Image");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG", "*.png"));
            File file = fileChooser.showSaveDialog(stage);
            if (file != null) {
                WritableImage snapshot = scene.snapshot(null);
                try {
                    ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        StackPane controls = new StackPane(saveBtn);
        controls.setTranslateX(10);
        controls.setTranslateY(10);
        root.getChildren().add(controls);

        stage.setScene(scene);
        stage.show();
    }
}