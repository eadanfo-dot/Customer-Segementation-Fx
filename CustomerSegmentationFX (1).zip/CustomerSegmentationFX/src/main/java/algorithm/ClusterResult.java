package algorithm;

import model.Customer;
import java.util.List;

public record ClusterResult(List<List<Customer>> clusters, double[][] centroids) {}