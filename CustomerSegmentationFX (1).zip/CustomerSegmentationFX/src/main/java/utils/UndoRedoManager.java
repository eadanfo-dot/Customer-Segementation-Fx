package utils;

import model.Customer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

public class UndoRedoManager {
    private final LinkedList<List<Customer>> undoStack = new LinkedList<>();
    private final LinkedList<List<Customer>> redoStack = new LinkedList<>();
    private final int maxSize;
    private Consumer<List<Customer>> stateApplier; // to apply saved state to UI

    public UndoRedoManager(int maxSize, Consumer<List<Customer>> applier) {
        this.maxSize = maxSize;
        this.stateApplier = applier;
    }

    public void saveState(List<Customer> currentState) {
        // Deep copy the list
        List<Customer> copy = new ArrayList<>();
        for (Customer c : currentState) {
            copy.add(new Customer(c.getAge(), c.getSpendingScore(), c.getPurchaseAmount()));
        }
        undoStack.push(copy);
        if (undoStack.size() > maxSize) undoStack.removeLast();
        redoStack.clear(); // new action clears redo
    }

    public boolean canUndo() { return !undoStack.isEmpty(); }
    public boolean canRedo() { return !redoStack.isEmpty(); }

    public void undo() {
        if (!canUndo()) return;
        List<Customer> current = undoStack.pop();
        // To support multiple undos, we need to push the previous state onto redo
        // But we need to know the state before the undo. We'll rely on the caller to provide the current state.
        // Actually, we'll just call the applier with the state to restore.
        // The caller should push the current state before performing undo.
        // For simplicity, we'll require the caller to push before calling undo.
        stateApplier.accept(current);
    }

    public void redo() {
        if (!canRedo()) return;
        List<Customer> state = redoStack.pop();
        stateApplier.accept(state);
    }

    public void pushRedoState(List<Customer> state) {
        List<Customer> copy = new ArrayList<>();
        for (Customer c : state) copy.add(new Customer(c.getAge(), c.getSpendingScore(), c.getPurchaseAmount()));
        redoStack.push(copy);
    }
}