package algorithm;

import model.Customer;
import utils.DistanceCalculator;
import utils.Normalizer;

import java.util.*;

public class KMeans {
    private final int K;
    private final int maxIterations;
    private Normalizer normalizer = null;
    private boolean useNormalization = false;

    public KMeans(int K, int maxIterations, boolean useNormalization, List<Customer> customers) {
        this.K = K;
        this.maxIterations = maxIterations;
        this.useNormalization = useNormalization;
        if (useNormalization) {
            this.normalizer = new Normalizer(customers);
        }
    }

    public ClusterResult fit(List<Customer> customers) {
        // Convert to feature matrix
        double[][] features = new double[customers.size()][3];
        for (int i = 0; i < customers.size(); i++) {
            if (useNormalization) {
                features[i] = normalizer.normalize(customers.get(i));
            } else {
                features[i] = customers.get(i).getFeatures();
            }
        }

        // K-means++ initialization
        double[][] centroids = initCentroidsKMeansPlusPlus(features);

        // Iterate
        int[] assignments = new int[features.length];
        for (int iter = 0; iter < maxIterations; iter++) {
            // Assign clusters
            boolean changed = assignClusters(features, centroids, assignments);
            if (!changed) break;
            // Update centroids
            centroids = updateCentroids(features, assignments, K);
        }

        // Build clusters from assignments
        List<List<Customer>> clusters = new ArrayList<>();
        for (int i = 0; i < K; i++) clusters.add(new ArrayList<>());
        for (int i = 0; i < customers.size(); i++) {
            clusters.get(assignments[i]).add(customers.get(i));
        }

        // Denormalize centroids if needed
        double[][] displayCentroids = centroids.clone();
        if (useNormalization) {
            for (int i = 0; i < centroids.length; i++) {
                displayCentroids[i] = normalizer.denormalize(centroids[i]);
            }
        }

        return new ClusterResult(clusters, displayCentroids);
    }

    private double[][] initCentroidsKMeansPlusPlus(double[][] features) {
        Random rand = new Random();
        double[][] centroids = new double[K][3];
        // Choose first centroid randomly
        centroids[0] = features[rand.nextInt(features.length)].clone();

        for (int i = 1; i < K; i++) {
            double[] distSq = new double[features.length];
            double sum = 0;
            for (int j = 0; j < features.length; j++) {
                double minDist = Double.MAX_VALUE;
                for (int k = 0; k < i; k++) {
                    double d = DistanceCalculator.calculate(features[j], centroids[k]);
                    minDist = Math.min(minDist, d);
                }
                distSq[j] = minDist * minDist;
                sum += distSq[j];
            }
            double r = rand.nextDouble() * sum;
            double cumulative = 0;
            int chosen = 0;
            for (int j = 0; j < features.length; j++) {
                cumulative += distSq[j];
                if (cumulative >= r) {
                    chosen = j;
                    break;
                }
            }
            centroids[i] = features[chosen].clone();
        }
        return centroids;
    }

    private boolean assignClusters(double[][] features, double[][] centroids, int[] assignments) {
        boolean changed = false;
        for (int i = 0; i < features.length; i++) {
            double minDist = Double.MAX_VALUE;
            int best = 0;
            for (int j = 0; j < K; j++) {
                double d = DistanceCalculator.calculate(features[i], centroids[j]);
                if (d < minDist) {
                    minDist = d;
                    best = j;
                }
            }
            if (assignments[i] != best) {
                assignments[i] = best;
                changed = true;
            }
        }
        return changed;
    }

    private double[][] updateCentroids(double[][] features, int[] assignments, int K) {
        double[][] newCentroids = new double[K][3];
        int[] counts = new int[K];
        for (int i = 0; i < features.length; i++) {
            int cluster = assignments[i];
            newCentroids[cluster][0] += features[i][0];
            newCentroids[cluster][1] += features[i][1];
            newCentroids[cluster][2] += features[i][2];
            counts[cluster]++;
        }
        for (int i = 0; i < K; i++) {
            if (counts[i] > 0) {
                newCentroids[i][0] /= counts[i];
                newCentroids[i][1] /= counts[i];
                newCentroids[i][2] /= counts[i];
            }
        }
        return newCentroids;
    }

    public static double computeInertia(List<Customer> customers, double[][] centroids, boolean useNormalization, Normalizer normalizer) {
        double inertia = 0.0;
        for (Customer c : customers) {
            double[] feat = useNormalization ? normalizer.normalize(c) : c.getFeatures();
            double minDist = Double.MAX_VALUE;
            for (double[] centroid : centroids) {
                double d = DistanceCalculator.calculate(feat, centroid);
                minDist = Math.min(minDist, d);
            }
            inertia += minDist * minDist;
        }
        return inertia;
    }
}