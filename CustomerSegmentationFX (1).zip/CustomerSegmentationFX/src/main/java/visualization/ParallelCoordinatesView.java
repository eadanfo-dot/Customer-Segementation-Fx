package visualization;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Customer;
import algorithm.ClusterResult;
import java.util.List;

public class ParallelCoordinatesView {

    public static void show(List<Customer> customers, ClusterResult result, String title) {
        Stage stage = new Stage();
        stage.setTitle(title);

        int width = 800;
        int height = 600;
        Canvas canvas = new Canvas(width, height);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Draw axes
        double[] xPos = {width*0.1, width*0.3, width*0.5, width*0.7, width*0.9};
        String[] labels = {"Age", "Spending", "Purchase"};
        for (int i = 0; i < xPos.length; i++) {
            gc.strokeLine(xPos[i], 50, xPos[i], height-50);
            gc.fillText(labels[i], xPos[i]-20, 30);
        }

        // Normalize values
        double minAge = customers.stream().mapToInt(Customer::getAge).min().orElse(0);
        double maxAge = customers.stream().mapToInt(Customer::getAge).max().orElse(1);
        double minSpending = customers.stream().mapToDouble(Customer::getSpendingScore).min().orElse(0);
        double maxSpending = customers.stream().mapToDouble(Customer::getSpendingScore).max().orElse(1);
        double minPurchase = customers.stream().mapToDouble(Customer::getPurchaseAmount).min().orElse(0);
        double maxPurchase = customers.stream().mapToDouble(Customer::getPurchaseAmount).max().orElse(1);

        // Color by cluster
        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE, Color.PURPLE, Color.CYAN, Color.MAGENTA, Color.YELLOW, Color.BROWN, Color.PINK};

        List<List<Customer>> clusters = result.clusters();
        for (int ci = 0; ci < clusters.size(); ci++) {
            Color color = colors[ci % colors.length];
            gc.setStroke(color);
            for (Customer c : clusters.get(ci)) {
                double normAge = (c.getAge() - minAge) / (maxAge - minAge) * (height-100) + 50;
                double normSpending = (c.getSpendingScore() - minSpending) / (maxSpending - minSpending) * (height-100) + 50;
                double normPurchase = (c.getPurchaseAmount() - minPurchase) / (maxPurchase - minPurchase) * (height-100) + 50;

                gc.beginPath();
                gc.moveTo(xPos[0], normAge);
                gc.lineTo(xPos[1], normSpending);
                gc.lineTo(xPos[2], normPurchase);
                gc.stroke();
            }
        }

        VBox root = new VBox(canvas);
        Scene scene = new Scene(root, width, height);
        stage.setScene(scene);
        stage.show();
    }
}