package visualization;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Customer;
import algorithm.ClusterResult;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.function.ToDoubleFunction;

public class ScatterPlotView {

    public static void show(List<Customer> customers, ClusterResult result, String title,
                            String xAxisLabel, String yAxisLabel) {
        Stage stage = new Stage();
        stage.setTitle(title);

        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel(xAxisLabel);
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel(yAxisLabel);

        ScatterChart<Number, Number> chart = new ScatterChart<>(xAxis, yAxis);
        chart.setTitle("Customer Segmentation");

        ToDoubleFunction<Customer> xExtractor = getExtractor(xAxisLabel);
        ToDoubleFunction<Customer> yExtractor = getExtractor(yAxisLabel);

        List<List<Customer>> clusters = result.clusters();
        double[][] centroids = result.centroids();
        int clusterIndex = 1;

        // Color palette (unused now, but could be used to style series)
        // We'll leave it commented to avoid warning.
        // String[] colors = {"red", "blue", "green", "orange", "purple", "cyan", "magenta", "yellow", "brown", "pink"};

        for (List<Customer> cluster : clusters) {
            XYChart.Series<Number, Number> series = new XYChart.Series<>();
            series.setName("Cluster " + clusterIndex);
            for (Customer c : cluster) {
                series.getData().add(new XYChart.Data<>(xExtractor.applyAsDouble(c), yExtractor.applyAsDouble(c)));
            }
            chart.getData().add(series);
            clusterIndex++;
        }

        // Add centroids series
        XYChart.Series<Number, Number> centroidSeries = new XYChart.Series<>();
        centroidSeries.setName("Centroids");
        for (double[] centroid : centroids) {
            double xVal = mapCentroidValue(centroid, xAxisLabel);
            double yVal = mapCentroidValue(centroid, yAxisLabel);
            centroidSeries.getData().add(new XYChart.Data<>(xVal, yVal));
        }
        chart.getData().add(centroidSeries);

        // Save button
        Button saveBtn = new Button("Save as Image");
        saveBtn.setOnAction(_ -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Chart as Image");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG", "*.png"));
            File file = fileChooser.showSaveDialog(stage);
            if (file != null) {
                WritableImage snapshot = chart.snapshot(null, null);
                try {
                    ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);
                } catch (IOException ex) {
                    // In a real app, use logging
                    ex.printStackTrace();
                }
            }
        });

        VBox vbox = new VBox(chart, saveBtn);
        Scene scene = new Scene(vbox, 800, 600);
        stage.setScene(scene);
        stage.show();
    }

    public static void showAndSave(List<Customer> customers, ClusterResult result, String title,
                                   String xAxisLabel, String yAxisLabel, Stage owner) {
        // Reuse show() – the save button is already there.
        show(customers, result, title, xAxisLabel, yAxisLabel);
    }

    private static ToDoubleFunction<Customer> getExtractor(String label) {
        return switch (label) {
            case "Age" -> Customer::getAge;
            case "Spending Score" -> Customer::getSpendingScore;
            case "Purchase Amount" -> Customer::getPurchaseAmount;
            default -> Customer::getSpendingScore;
        };
    }

    private static double mapCentroidValue(double[] centroid, String label) {
        // centroid[0] = age, centroid[1] = spending, centroid[2] = purchase
        return switch (label) {
            case "Age" -> centroid[0];
            case "Spending Score" -> centroid[1];
            case "Purchase Amount" -> centroid[2];
            default -> centroid[1];
        };
    }
}