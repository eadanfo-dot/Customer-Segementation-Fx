module com.example.customersegmentationfx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;

    opens com.example.customersegmentationfx to javafx.fxml;
    exports main;

}