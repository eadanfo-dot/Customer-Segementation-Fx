package utils;

import model.Customer;

import java.util.List;

public class Normalizer {
    private double minAge, maxAge;
    private double minSpending, maxSpending;
    private double minPurchase, maxPurchase;

    public Normalizer(List<Customer> customers) {
        // Compute min/max for each feature
        minAge = customers.stream().mapToInt(Customer::getAge).min().orElse(0);
        maxAge = customers.stream().mapToInt(Customer::getAge).max().orElse(1);
        minSpending = customers.stream().mapToDouble(Customer::getSpendingScore).min().orElse(0);
        maxSpending = customers.stream().mapToDouble(Customer::getSpendingScore).max().orElse(1);
        minPurchase = customers.stream().mapToDouble(Customer::getPurchaseAmount).min().orElse(0);
        maxPurchase = customers.stream().mapToDouble(Customer::getPurchaseAmount).max().orElse(1);
    }

    public double[] normalize(Customer c) {
        double normAge = (maxAge == minAge) ? 0 : (c.getAge() - minAge) / (maxAge - minAge);
        double normSpending = (maxSpending == minSpending) ? 0 : (c.getSpendingScore() - minSpending) / (maxSpending - minSpending);
        double normPurchase = (maxPurchase == minPurchase) ? 0 : (c.getPurchaseAmount() - minPurchase) / (maxPurchase - minPurchase);
        return new double[]{normAge, normSpending, normPurchase};
    }

    public double[] denormalize(double[] norm) {
        double age = norm[0] * (maxAge - minAge) + minAge;
        double spending = norm[1] * (maxSpending - minSpending) + minSpending;
        double purchase = norm[2] * (maxPurchase - minPurchase) + minPurchase;
        return new double[]{age, spending, purchase};
    }
}