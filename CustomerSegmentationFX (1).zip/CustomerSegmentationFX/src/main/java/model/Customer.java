package model;

import javafx.beans.property.*;

public class Customer {
    private final IntegerProperty age = new SimpleIntegerProperty();
    private final DoubleProperty spendingScore = new SimpleDoubleProperty();
    private final DoubleProperty purchaseAmount = new SimpleDoubleProperty();

    public Customer(int age, double spendingScore, double purchaseAmount) {
        setAge(age);
        setSpendingScore(spendingScore);
        setPurchaseAmount(purchaseAmount);
    }

    public int getAge() { return age.get(); }
    public void setAge(int age) { this.age.set(age); }
    public IntegerProperty ageProperty() { return age; }

    public double getSpendingScore() { return spendingScore.get(); }
    public void setSpendingScore(double spendingScore) { this.spendingScore.set(spendingScore); }
    public DoubleProperty spendingScoreProperty() { return spendingScore; }

    public double getPurchaseAmount() { return purchaseAmount.get(); }
    public void setPurchaseAmount(double purchaseAmount) { this.purchaseAmount.set(purchaseAmount); }
    public DoubleProperty purchaseAmountProperty() { return purchaseAmount; }

    public double[] getFeatures() {
        return new double[]{getAge(), getSpendingScore(), getPurchaseAmount()};
    }
}