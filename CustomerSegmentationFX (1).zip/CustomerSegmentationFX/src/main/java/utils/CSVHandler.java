package utils;

import model.Customer;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class CSVHandler {

    public static List<Customer> readCustomers(String filePath, int ageCol, int spendingCol, int purchaseCol) throws IOException {
        List<Customer> customers = new ArrayList<>();
        Path path = Paths.get(filePath);
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                String[] parts = line.split(",");
                try {
                    int age = Integer.parseInt(parts[ageCol].trim());
                    double spending = Double.parseDouble(parts[spendingCol].trim());
                    double purchase = Double.parseDouble(parts[purchaseCol].trim());
                    customers.add(new Customer(age, spending, purchase));
                } catch (NumberFormatException e) {
                    // skip invalid line
                }
            }
        }
        return customers;
    }

    public static void writeCustomers(String filePath, List<Customer> customers) throws IOException {
        Path path = Paths.get(filePath);
        try (BufferedWriter writer = Files.newBufferedWriter(path)) {
            writer.write("Age,SpendingScore,PurchaseAmount");
            writer.newLine();
            for (Customer c : customers) {
                writer.write(String.format("%d,%.2f,%.2f", c.getAge(), c.getSpendingScore(), c.getPurchaseAmount()));
                writer.newLine();
            }
        }
    }

    public static void writeClusteredCustomers(String filePath, List<Customer> customers, int[] assignments, double[][] centroids) throws IOException {
        Path path = Paths.get(filePath);
        try (BufferedWriter writer = Files.newBufferedWriter(path)) {
            writer.write("Age,SpendingScore,PurchaseAmount,ClusterLabel");
            writer.newLine();
            for (int i = 0; i < customers.size(); i++) {
                Customer c = customers.get(i);
                writer.write(String.format("%d,%.2f,%.2f,%d", c.getAge(), c.getSpendingScore(), c.getPurchaseAmount(), assignments[i]));
                writer.newLine();
            }
        }
    }
}