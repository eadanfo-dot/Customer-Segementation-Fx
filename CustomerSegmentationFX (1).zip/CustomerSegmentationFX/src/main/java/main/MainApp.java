package main;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Customer;
import algorithm.KMeans;
import algorithm.ClusterResult;
import utils.CSVHandler;
import utils.Normalizer;
import utils.UndoRedoManager;
import visualization.ScatterPlotView;
import visualization.ScatterPlot3DView;
import visualization.ParallelCoordinatesView;

import javafx.scene.image.Image;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class MainApp extends Application {

    private final ObservableList<Customer> customerList = FXCollections.observableArrayList();
    private TableView<Customer> customerTable;
    private TextArea resultArea;
    private TextArea centroidsArea;
    private TextField kField;
    private TextField iterField;
    private CheckBox normalizeCheckBox;
    private ComboBox<String> xAxisCombo;
    private ComboBox<String> yAxisCombo;
    private UndoRedoManager undoRedoManager;

    @Override
    public void start(Stage primaryStage) {
        // Load the icon from the resources
        Image icon = new Image(getClass().getResourceAsStream("/images/myicon.png"));
        primaryStage.getIcons().add(icon);
        primaryStage.setTitle("Customer Segmentation with K-Means");

        // ---- Initialise undo/redo manager ----
        undoRedoManager = new UndoRedoManager(20, state -> {
            customerList.setAll(state);
            // after restoring, save state for future undos
            saveStateForUndo();
        });

        // ---- Table ----
        customerTable = new TableView<>();
        customerTable.setItems(customerList);
        customerTable.setEditable(true);

        TableColumn<Customer, Integer> ageCol = new TableColumn<>("Age");
        ageCol.setCellValueFactory(cellData -> cellData.getValue().ageProperty().asObject());

        TableColumn<Customer, Double> spendingCol = new TableColumn<>("Spending Score");
        spendingCol.setCellValueFactory(cellData -> cellData.getValue().spendingScoreProperty().asObject());

        TableColumn<Customer, Double> purchaseCol = new TableColumn<>("Purchase Amount");
        purchaseCol.setCellValueFactory(cellData -> cellData.getValue().purchaseAmountProperty().asObject());

        @SuppressWarnings("unchecked")
        TableColumn<Customer, ?>[] columns = new TableColumn[]{ageCol, spendingCol, purchaseCol};
        customerTable.getColumns().addAll(columns);

        // ---- Buttons and controls ----
        Button addBtn = new Button("Add Customer");
        addBtn.setTooltip(new Tooltip("Add a new customer manually"));
        addBtn.setOnAction(_ -> addCustomerDialog());

        Button removeBtn = new Button("Remove Selected");
        removeBtn.setTooltip(new Tooltip("Remove the selected customer from the list"));
        removeBtn.setOnAction(_ -> {
            Customer selected = customerTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                saveStateForUndo();
                customerList.remove(selected);
            }
        });

        Button loadBtn = new Button("Load CSV");
        loadBtn.setTooltip(new Tooltip("Load customers from a CSV file (you can map columns)"));
        loadBtn.setOnAction(_ -> loadCSV(primaryStage));

        Button saveBtn = new Button("Save CSV");
        saveBtn.setTooltip(new Tooltip("Save the current customer list to a CSV file"));
        saveBtn.setOnAction(_ -> saveCSV(primaryStage));

        Button exportResultsBtn = new Button("Export Results");
        exportResultsBtn.setTooltip(new Tooltip("Export clustered customers with cluster labels to a CSV file"));
        exportResultsBtn.setOnAction(_ -> exportResults(primaryStage));

        // K and iterations
        kField = new TextField("3");
        kField.setPromptText("K");
        kField.setPrefWidth(50);
        kField.setTooltip(new Tooltip("Number of clusters (K)"));

        iterField = new TextField("10");
        iterField.setPromptText("Iterations");
        iterField.setPrefWidth(70);
        iterField.setTooltip(new Tooltip("Maximum number of iterations"));

        normalizeCheckBox = new CheckBox("Normalize");
        normalizeCheckBox.setTooltip(new Tooltip("Normalize features before clustering"));

        Button runBtn = new Button("Run K-Means");
        runBtn.setTooltip(new Tooltip("Run the K-Means algorithm with current settings"));
        runBtn.setOnAction(_ -> runClustering());

        Button suggestKBtn = new Button("Suggest K");
        suggestKBtn.setTooltip(new Tooltip("Show elbow method chart and suggest optimal K"));
        suggestKBtn.setOnAction(_ -> suggestOptimalK());

        Button setKBtn = new Button("Auto-set K");
        setKBtn.setTooltip(new Tooltip("Automatically set K to the suggested value"));
        setKBtn.setOnAction(_ -> autoSetK());

        Button undoBtn = new Button("Undo");
        undoBtn.setTooltip(new Tooltip("Undo last modification (add/remove/edit)"));
        undoBtn.setOnAction(_ -> undo());

        Button redoBtn = new Button("Redo");
        redoBtn.setTooltip(new Tooltip("Redo last undone modification"));
        redoBtn.setOnAction(_ -> redo());

        // Visualization buttons
        Button showPlotBtn = new Button("2D Scatter");
        showPlotBtn.setTooltip(new Tooltip("Show 2D scatter plot (customizable axes)"));
        showPlotBtn.setOnAction(_ -> show2DScatter());

        Button show3DPlotBtn = new Button("3D Scatter");
        show3DPlotBtn.setTooltip(new Tooltip("Show 3D scatter plot (age, spending, purchase)"));
        show3DPlotBtn.setOnAction(_ -> show3DScatter());

        Button parallelCoordsBtn = new Button("Parallel Coords");
        parallelCoordsBtn.setTooltip(new Tooltip("Show parallel coordinates plot"));
        parallelCoordsBtn.setOnAction(_ -> showParallelCoordinates());

        Button savePlotBtn = new Button("Save Plot");
        savePlotBtn.setTooltip(new Tooltip("Save the current 2D scatter plot as an image"));
        savePlotBtn.setOnAction(_ -> saveCurrentPlot(primaryStage));

        // Axes selection for 2D scatter
        xAxisCombo = new ComboBox<>();
        xAxisCombo.getItems().addAll("Age", "Spending Score", "Purchase Amount");
        xAxisCombo.setValue("Spending Score");
        xAxisCombo.setTooltip(new Tooltip("Choose X-axis for 2D scatter plot"));

        yAxisCombo = new ComboBox<>();
        yAxisCombo.getItems().addAll("Age", "Spending Score", "Purchase Amount");
        yAxisCombo.setValue("Purchase Amount");
        yAxisCombo.setTooltip(new Tooltip("Choose Y-axis for 2D scatter plot"));

        // Result areas
        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setPrefRowCount(12);
        centroidsArea = new TextArea();
        centroidsArea.setEditable(false);
        centroidsArea.setPrefRowCount(5);
        centroidsArea.setPromptText("Centroids will appear here");

        // ---- ToolBars ----
        // Core actions toolbar
        ToolBar coreToolBar = new ToolBar(
                loadBtn, saveBtn, exportResultsBtn,
                new Separator(),
                addBtn, removeBtn, undoBtn, redoBtn,
                new Separator(),
                kField, iterField, normalizeCheckBox,
                new Separator(),
                runBtn, suggestKBtn, setKBtn
        );
        coreToolBar.setPrefHeight(40);

        // Visualization toolbar
        ToolBar vizToolBar = new ToolBar(
                new Label("Visualization:"),
                showPlotBtn, show3DPlotBtn, parallelCoordsBtn, savePlotBtn,
                new Label("Axes:"), xAxisCombo, yAxisCombo
        );
        vizToolBar.setPrefHeight(40);

        // ---- TabPane ----
        TabPane tabPane = new TabPane();

        // Customers tab
        VBox customerTabContent = new VBox(10, coreToolBar, vizToolBar, customerTable);
        Tab customersTab = new Tab("Customers", customerTabContent);
        customersTab.setClosable(false);

        // Results tab
        VBox resultsTabContent = new VBox(10,
                new Label("Cluster Assignments:"), resultArea,
                new Label("Centroid Positions (Age, Spending, Purchase):"), centroidsArea);
        resultsTabContent.setPadding(new Insets(5));
        Tab resultsTab = new Tab("Clusters", resultsTabContent);
        resultsTab.setClosable(false);

        tabPane.getTabs().addAll(customersTab, resultsTab);

        // ---- Main layout ----
        VBox root = new VBox(10, tabPane);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 1100, 750);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Load example data
        addExampleData();
        saveStateForUndo(); // initial state for undo
    }

    // ---------- Undo/Redo ----------
    private void saveStateForUndo() {
        undoRedoManager.saveState(new ArrayList<>(customerList));
    }

    private void undo() {
        if (undoRedoManager.canUndo()) {
            undoRedoManager.pushRedoState(new ArrayList<>(customerList));
            undoRedoManager.undo();
        }
    }

    private void redo() {
        if (undoRedoManager.canRedo()) {
            undoRedoManager.saveState(new ArrayList<>(customerList));
            undoRedoManager.redo();
        }
    }

    // ---------- CSV operations ----------
    private void loadCSV(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Load Customers CSV");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            TextInputDialog dialog = new TextInputDialog("0,1,2");
            dialog.setTitle("Column Mapping");
            dialog.setHeaderText("Enter column indices (0-based) for Age, Spending Score, Purchase Amount separated by commas");
            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String[] parts = result.get().split(",");
                if (parts.length == 3) {
                    try {
                        int ageCol = Integer.parseInt(parts[0].trim());
                        int spendingCol = Integer.parseInt(parts[1].trim());
                        int purchaseCol = Integer.parseInt(parts[2].trim());
                        List<Customer> loaded = CSVHandler.readCustomers(file.getAbsolutePath(), ageCol, spendingCol, purchaseCol);
                        saveStateForUndo();
                        customerList.setAll(loaded);
                        showAlert("Loaded " + loaded.size() + " customers.");
                    } catch (NumberFormatException | IOException e) {
                        showAlert("Error loading file: " + e.getMessage());
                    }
                } else {
                    showAlert("Invalid column mapping. Using defaults (0,1,2).");
                }
            }
        }
    }

    private void saveCSV(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Customers CSV");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(stage);
        if (file != null) {
            try {
                CSVHandler.writeCustomers(file.getAbsolutePath(), new ArrayList<>(customerList));
                showAlert("Saved " + customerList.size() + " customers.");
            } catch (IOException e) {
                showAlert("Error saving file: " + e.getMessage());
            }
        }
    }

    private void exportResults(Stage stage) {
        if (customerList.isEmpty()) {
            showAlert("No customers to export.");
            return;
        }
        int K = getKFromField();
        int iterations = getIterationsFromField();
        if (K <= 0 || iterations <= 0) return;
        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, iterations, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        // Build assignment array
        Map<Customer, Integer> assignmentMap = new HashMap<>();
        for (int i = 0; i < result.clusters().size(); i++) {
            for (Customer c : result.clusters().get(i)) {
                assignmentMap.put(c, i);
            }
        }
        int[] assignments = new int[customers.size()];
        for (int i = 0; i < customers.size(); i++) {
            assignments[i] = assignmentMap.get(customers.get(i));
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export Clustered Customers");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(stage);
        if (file != null) {
            try {
                CSVHandler.writeClusteredCustomers(file.getAbsolutePath(), customers, assignments, result.centroids());
                showAlert("Exported " + customers.size() + " customers with cluster labels.");
            } catch (IOException e) {
                showAlert("Error exporting file: " + e.getMessage());
            }
        }
    }

    // ---------- Clustering ----------
    private void runClustering() {
        if (customerList.isEmpty()) {
            showAlert("No customers to cluster.");
            return;
        }

        int K = getKFromField();
        int iterations = getIterationsFromField();
        if (K <= 0 || iterations <= 0) return;

        if (K > customerList.size()) {
            showAlert("K cannot be larger than the number of customers.");
            return;
        }

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, iterations, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        // Show clusters
        StringBuilder clusterSb = new StringBuilder();
        int clusterIdx = 1;
        for (List<Customer> cluster : result.clusters()) {
            clusterSb.append("Cluster ").append(clusterIdx++).append(" (size: ").append(cluster.size()).append(")\n");
            for (Customer c : cluster) {
                clusterSb.append(String.format("  Age: %d, Spending: %.2f, Purchase: %.2f\n",
                        c.getAge(), c.getSpendingScore(), c.getPurchaseAmount()));
            }
            clusterSb.append("\n");
        }
        resultArea.setText(clusterSb.toString());

        // Show centroids
        StringBuilder centroidSb = new StringBuilder();
        double[][] centroids = result.centroids();
        for (int i = 0; i < centroids.length; i++) {
            centroidSb.append(String.format("Centroid %d: Age=%.2f, Spending=%.2f, Purchase=%.2f\n",
                    i + 1, centroids[i][0], centroids[i][1], centroids[i][2]));
        }
        centroidsArea.setText(centroidSb.toString());
    }

    // ---------- Elbow method ----------
    private void suggestOptimalK() {
        if (customerList.size() < 3) {
            showAlert("Need at least 3 customers to compute elbow.");
            return;
        }

        int maxK = Math.min(10, customerList.size());
        List<Double> inertias = new ArrayList<>();
        List<Integer> ks = new ArrayList<>();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        Normalizer normalizer = useNorm ? new Normalizer(customers) : null;

        for (int k = 1; k <= maxK; k++) {
            KMeans kmeans = new KMeans(k, 10, useNorm, customers);
            ClusterResult result = kmeans.fit(customers);
            double inertia = KMeans.computeInertia(customers, result.centroids(), useNorm, normalizer);
            inertias.add(inertia);
            ks.add(k);
        }

        StringBuilder msg = new StringBuilder("Inertia values:\n");
        for (int i = 0; i < ks.size(); i++) {
            msg.append(String.format("K = %d: inertia = %.2f\n", ks.get(i), inertias.get(i)));
        }

        // Find elbow (point where improvement drops significantly)
        int suggestedK = 1;
        if (inertias.size() >= 3) {
            double maxChange = 0;
            for (int i = 1; i < inertias.size() - 1; i++) {
                double prevDiff = inertias.get(i - 1) - inertias.get(i);
                double currDiff = inertias.get(i) - inertias.get(i + 1);
                double change = prevDiff - currDiff;
                if (change > maxChange) {
                    maxChange = change;
                    suggestedK = ks.get(i);
                }
            }
        }

        msg.append("\nSuggested K (elbow): ").append(suggestedK);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Elbow Method");
        alert.setHeaderText("Optimal K Suggestion");
        alert.setContentText(msg.toString());
        alert.showAndWait();
    }

    private void autoSetK() {
        if (customerList.size() < 3) {
            showAlert("Need at least 3 customers to compute elbow.");
            return;
        }

        int maxK = Math.min(10, customerList.size());
        List<Double> inertias = new ArrayList<>();
        List<Integer> ks = new ArrayList<>();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        Normalizer normalizer = useNorm ? new Normalizer(customers) : null;

        for (int k = 1; k <= maxK; k++) {
            KMeans kmeans = new KMeans(k, 10, useNorm, customers);
            ClusterResult result = kmeans.fit(customers);
            double inertia = KMeans.computeInertia(customers, result.centroids(), useNorm, normalizer);
            inertias.add(inertia);
            ks.add(k);
        }

        int suggestedK = 1;
        if (inertias.size() >= 3) {
            double maxChange = 0;
            for (int i = 1; i < inertias.size() - 1; i++) {
                double prevDiff = inertias.get(i - 1) - inertias.get(i);
                double currDiff = inertias.get(i) - inertias.get(i + 1);
                double change = prevDiff - currDiff;
                if (change > maxChange) {
                    maxChange = change;
                    suggestedK = ks.get(i);
                }
            }
        }

        kField.setText(String.valueOf(suggestedK));
    }

    // ---------- Visualization ----------
    private void show2DScatter() {
        if (customerList.isEmpty()) {
            showAlert("No customers to plot.");
            return;
        }

        int K = getKFromField();
        if (K <= 0) K = 3;
        if (K > customerList.size()) K = customerList.size();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, 10, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        String xAxis = xAxisCombo.getValue();
        String yAxis = yAxisCombo.getValue();
        ScatterPlotView.show(customers, result, "Customer Clusters", xAxis, yAxis);
    }

    private void show3DScatter() {
        if (customerList.isEmpty()) {
            showAlert("No customers to plot.");
            return;
        }

        int K = getKFromField();
        if (K <= 0) K = 3;
        if (K > customerList.size()) K = customerList.size();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, 10, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        ScatterPlot3DView.show(customers, result, "3D Customer Clusters");
    }

    private void showParallelCoordinates() {
        if (customerList.isEmpty()) {
            showAlert("No customers to plot.");
            return;
        }

        int K = getKFromField();
        if (K <= 0) K = 3;
        if (K > customerList.size()) K = customerList.size();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, 10, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        ParallelCoordinatesView.show(customers, result, "Parallel Coordinates");
    }

    private void saveCurrentPlot(Stage stage) {
        if (customerList.isEmpty()) {
            showAlert("No customers to plot.");
            return;
        }

        int K = getKFromField();
        if (K <= 0) K = 3;
        if (K > customerList.size()) K = customerList.size();

        boolean useNorm = normalizeCheckBox.isSelected();
        List<Customer> customers = new ArrayList<>(customerList);
        KMeans kmeans = new KMeans(K, 10, useNorm, customers);
        ClusterResult result = kmeans.fit(customers);

        String xAxis = xAxisCombo.getValue();
        String yAxis = yAxisCombo.getValue();
        ScatterPlotView.showAndSave(customers, result, "Customer Clusters", xAxis, yAxis, stage);
    }

    // ---------- Helper methods ----------
    private int getKFromField() {
        try {
            return Integer.parseInt(kField.getText().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private int getIterationsFromField() {
        try {
            return Integer.parseInt(iterField.getText().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void addCustomerDialog() {
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle("Add Customer");
        dialog.setHeaderText("Enter customer details");

        ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        TextField ageField = new TextField();
        TextField spendingField = new TextField();
        TextField purchaseField = new TextField();

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));
        grid.add(new Label("Age:"), 0, 0);
        grid.add(ageField, 1, 0);
        grid.add(new Label("Spending Score:"), 0, 1);
        grid.add(spendingField, 1, 1);
        grid.add(new Label("Purchase Amount:"), 0, 2);
        grid.add(purchaseField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType) {
                try {
                    int age = Integer.parseInt(ageField.getText());
                    double spending = Double.parseDouble(spendingField.getText());
                    double purchase = Double.parseDouble(purchaseField.getText());
                    return new Customer(age, spending, purchase);
                } catch (NumberFormatException ex) {
                    showAlert("Invalid number format");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(c -> {
            saveStateForUndo();
            customerList.add(c);
        });
    }

    private void addExampleData() {
        customerList.add(new Customer(22, 80, 500));
        customerList.add(new Customer(25, 75, 450));
        customerList.add(new Customer(45, 40, 200));
        customerList.add(new Customer(52, 30, 150));
        customerList.add(new Customer(23, 85, 520));
        customerList.add(new Customer(40, 35, 180));
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}